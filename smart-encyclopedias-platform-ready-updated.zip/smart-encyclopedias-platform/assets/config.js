window.STORE_CONFIG = {
  productName: 'الموسوعة الشاملة في الذكاء الاصطناعي',
  pages: 250,
  previewPages: 20,
  price: '150',
  currency: 'جنيه سوداني',
  oldPrice: '',
  offerTitle: 'احصل على النسخة الكاملة',
  offerText: 'الدفع من داخل السودان عبر بنكك. بعد التحويل أرسل إشعار الدفع عبر واتساب لتأكيد الطلب.',
  paymentMethod: 'بنكك',
  accountNumber: '1882224',
  whatsapp: '+249914488188',
  whatsappUrl: 'https://wa.me/249914488188',
  purchaseUrl: 'https://wa.me/249914488188',
  supportText: 'لإتمام الشراء: حوّل 150 جنيهًا سودانيًا عبر بنكك إلى الحساب 1882224، ثم أرسل إشعار التحويل عبر واتساب على +249914488188.'
};
